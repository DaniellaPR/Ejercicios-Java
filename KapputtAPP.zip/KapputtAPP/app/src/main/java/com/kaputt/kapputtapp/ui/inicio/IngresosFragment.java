package com.kaputt.kapputtapp.ui.inicio;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.kaputt.kapputtapp.R;
import com.kaputt.kapputtapp.ui.operacion.AñadirOperacionActivity;

public class IngresosFragment extends Fragment {

    public IngresosFragment() {
        // Constructor vacío requerido
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_ingresos, container, false);

        ImageButton btnAgregarIngreso = rootView.findViewById(R.id.btnAgregarDesdeInicio);
        btnAgregarIngreso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), AñadirOperacionActivity.class);
                intent.putExtra("selectedTab", 1); // 1 = Añadir Ingreso
                startActivity(intent);
            }
        });

        return rootView;
    }
}
