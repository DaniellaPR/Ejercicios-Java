package com.kaputt.kapputtapp.ui.inicio;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.kaputt.kapputtapp.R;
import com.kaputt.kapputtapp.ui.operacion.AñadirOperacionActivity;

public class GastosFragment extends Fragment {

    public GastosFragment() {

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_gastos, container, false);

        ImageButton btnAgregarGasto = rootView.findViewById(R.id.btnAgregarDesdeInicio);
        btnAgregarGasto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), AñadirOperacionActivity.class);
                intent.putExtra("selectedTab", 0); // 0 =Añadir Gasto
                startActivity(intent);
            }
        });

        return rootView;
    }
}
