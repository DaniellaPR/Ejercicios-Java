package com.kaputt.kapputtapp.ui.operacion;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import androidx.viewpager2.widget.ViewPager2;
import com.kaputt.kapputtapp.R;

public class AñadirOperacionActivity extends AppCompatActivity {

    private ViewPager2 viewPager;
    private TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anadir_operacion);

        viewPager = findViewById(R.id.viewPagerOperaciones);
        tabLayout = findViewById(R.id.tabLayoutOperaciones);

        viewPager.setAdapter(new OperacionesPagerAdapter(this));

        new TabLayoutMediator(tabLayout, viewPager,
                (tab, position) -> tab.setText(position == 0 ? "Añadir Gasto" : "Añadir Ingreso")
        ).attach();
    }
}
