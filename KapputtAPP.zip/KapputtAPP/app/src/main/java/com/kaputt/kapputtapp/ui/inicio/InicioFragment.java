package com.kaputt.kapputtapp.ui.inicio;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.kaputt.kapputtapp.R;
import com.kaputt.kapputtapp.ui.operacion.AñadirOperacionActivity;

public class InicioFragment extends Fragment {

    public InicioFragment() {

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_inicio, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view,
                              @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TabLayout tabLayout = view.findViewById(R.id.tabLayout);
        ViewPager2 viewPager = view.findViewById(R.id.viewPager);
        ImageButton btnAgregar = view.findViewById(R.id.btnAgregarDesdeInicio);

        ViewPagerAdapter adapter = new ViewPagerAdapter(requireActivity());
        viewPager.setAdapter(adapter);

        new TabLayoutMediator(tabLayout, viewPager,
                (tab, position) -> {
                    if (position == 0) {
                        tab.setText("Gastos");
                        tab.setIcon(R.drawable.ic_gastos);
                    } else if (position == 1) {
                        tab.setText("Ingresos");
                        tab.setIcon(R.drawable.ic_ingresos);
                    }
                }).attach();

        btnAgregar.setOnClickListener(v -> {
            int selectedTab = viewPager.getCurrentItem(); // 0 = Gastos, 1 = Ingresos
            Intent intent = new Intent(getContext(), AñadirOperacionActivity.class);
            intent.putExtra("selectedTab", selectedTab);
            startActivity(intent);
        });
    }
}
