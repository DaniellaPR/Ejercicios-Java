package com.kaputt.kapputtapp.ui.operacion;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class OperacionesPagerAdapter extends FragmentStateAdapter {

    public OperacionesPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        return position == 0 ? new AñadirGastoFragment() : new AñadirIngresoFragment();
    }

    @Override
    public int getItemCount() {
        return 2;
    }
}
