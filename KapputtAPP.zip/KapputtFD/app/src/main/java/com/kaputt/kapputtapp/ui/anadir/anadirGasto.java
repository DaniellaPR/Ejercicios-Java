package com.kaputt.kapputtapp.ui.anadir;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.kaputt.kapputtapp.MainActivity;
import com.kaputt.kapputtapp.R;

public class anadirGasto extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_add_gasto);

        Button btnVolver = findViewById(R.id.ConfAnadirGasto);
        btnVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent volverIntent = new Intent(anadirGasto.this, MainActivity.class);
                startActivity(volverIntent);
                finish(); // opcional: cierra esta actividad para que no quede en el back stack
            }
        });

        Button btnVolver2 = findViewById(R.id.volverAddGasto);
        btnVolver2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent volverIntent = new Intent(anadirGasto.this, MainActivity.class);
                startActivity(volverIntent);
                finish(); // opcional: cierra esta actividad para que no quede en el back stack
            }
        });
    }
}
