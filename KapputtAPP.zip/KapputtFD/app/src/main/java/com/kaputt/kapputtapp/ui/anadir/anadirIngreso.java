package com.kaputt.kapputtapp.ui.anadir;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.kaputt.kapputtapp.MainActivity;
import com.kaputt.kapputtapp.R;

public class anadirIngreso extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_add_ingreso);

        Button btnVolver = findViewById(R.id.button2);
        btnVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent volverIntent = new Intent(anadirIngreso.this, MainActivity.class);
                startActivity(volverIntent);
                finish(); 
            }
        });
        Button btnVolver2 = findViewById(R.id.VolverAddIngreso);
        btnVolver2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent volverIntent = new Intent(anadirIngreso.this, MainActivity.class);
                startActivity(volverIntent);
                finish();
            }
        });
    }
}
