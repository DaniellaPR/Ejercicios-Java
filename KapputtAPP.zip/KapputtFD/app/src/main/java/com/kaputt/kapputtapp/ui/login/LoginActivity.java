package com.kaputt.kapputtapp.ui.login;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.kaputt.kapputtapp.DBHelper;
import com.kaputt.kapputtapp.MainActivity;
import com.kaputt.kapputtapp.R;

import java.util.Calendar;
import java.text.SimpleDateFormat;


public class LoginActivity extends AppCompatActivity {
    DBHelper dbHelper = new DBHelper(this);
    private EditText usernameEditText;
    private EditText balanceEditText;
    private Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Validar si ya entró antes
        SharedPreferences prefs = getSharedPreferences("KaputtPrefs", MODE_PRIVATE);
        boolean isFirstTime = prefs.getBoolean("isFirstTime", true);

        if (!isFirstTime) {
            // Ya inició antes, redirigir directamente
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_login);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        usernameEditText = findViewById(R.id.username);
        balanceEditText = findViewById(R.id.editTextNumber);
        loginButton = findViewById(R.id.login);

        // Agregar las clasificaciones preexistentes en la app
        dbHelper.insertarClasificacion("COMIDA", "Gastos realizados en la adquisición de alimentos.");
        dbHelper.insertarClasificacion("TRANSPORTE", "Gastos realizados en transporte.");
        dbHelper.insertarClasificacion("SALUD_FISICA", "Gastos realizados en chequeos, citas médicas o medicina.");
        dbHelper.insertarClasificacion("SALUD_MENTAL", "Gastos realizados en citas psicológicas, o medicamentos.");
        dbHelper.insertarClasificacion("OCIO", "Gastos realizados actividades recreativas.");
        dbHelper.insertarClasificacion("HOGAR", "Gastos realizados los gastos para el hogar, limpieza, mantenimiento, etc.");
        dbHelper.insertarClasificacion("EDUCACION", "Gastos realizados el pago de actividades para aprendizaje.");
        dbHelper.insertarClasificacion("EJERCICIO", "Gastos realizados en el pago de equipo para ejercitar.");
        dbHelper.insertarClasificacion("HOBBIES", "Gastos realizados a aficiones o pasatiempos.");
        dbHelper.insertarClasificacion("OTROS", "Gastos realizados en otras actividades.");

        //Agrega los retos en la app
        // COMIDA
        dbHelper.insertarReto("Semana sin delivery", "Evita pedir comida a domicilio durante 7 días.", 15.0, null, null, "COMIDA","PENDIENTE");
        dbHelper.insertarReto("Cocina en casa", "Prepara todas tus comidas en casa por una semana.",  20.0, null, null, "COMIDA","PENDIENTE");


        // TRANSPORTE
        dbHelper.insertarReto("Camina al trabajo", "Usa transporte gratuito (caminar o bicicleta) 3 veces esta semana.",  10.0, null, null, "TRANSPORTE","PENDIENTE");
        dbHelper.insertarReto("No uses taxi", "Evita usar taxi o apps de transporte por 5 días.",  12.0, null, null, "TRANSPORTE","PENDIENTE");


        // SALUD MENTAL
        dbHelper.insertarReto("Día de autocuidado", "Dedica un día a actividades que te relajen sin gastar dinero.",  0.0, null, null, "SALUD_MENTAL","PENDIENTE");

        // OCIO
        dbHelper.insertarReto("Diversión gratuita", "Realiza 3 actividades de ocio gratuitas esta semana.",  0.0, null, null, "OCIO","PENDIENTE");
        dbHelper.insertarReto("Evita streaming pago", "No pagues servicios de entretenimiento por una semana.",  10.0, null, null, "OCIO","PENDIENTE");

        // HOGAR
        dbHelper.insertarReto("Ahorra en limpieza", "Usa solo productos de limpieza que ya tienes.",  8.0, null, null, "HOGAR","PENDIENTE");
        dbHelper.insertarReto("Gasto consciente en hogar", "Revisa los gastos del hogar y elimina uno innecesario.",  15.0, null, null, "HOGAR","PENDIENTE");

        // EDUCACIÓN
        dbHelper.insertarReto("Aprende sin gastar", "Realiza un curso gratuito en línea esta semana.",  0.0, null, null, "EDUCACION","PENDIENTE");
        dbHelper.insertarReto("Invierte en aprender", "Compra un libro o curso útil sin excederte de presupuesto.",  10.0, null, null, "EDUCACION","PENDIENTE");

        // EJERCICIO
        dbHelper.insertarReto("Entrena en casa", "Haz al menos 3 sesiones de ejercicio sin pagar gimnasio.",  5.0, null, null, "EJERCICIO","PENDIENTE");
        dbHelper.insertarReto("Crea rutina sin equipo", "Entrena usando solo tu cuerpo esta semana.", 0.0, null, null, "EJERCICIO","PENDIENTE");

        // HOBBIES
        dbHelper.insertarReto("Crea con lo que tienes", "Haz algo relacionado a tu hobby sin comprar materiales nuevos.",  0.0, null, null, "HOBBIES","PENDIENTE");
        dbHelper.insertarReto("Hobby económico", "Dedica tiempo a tu hobby pero gasta menos de $5.",  5.0, null, null, "HOBBIES","PENDIENTE");

        // OTROS
        dbHelper.insertarReto("Día sin gastar", "Elige un día de la semana en el que no gastes nada.",  0.0, null, null, "OTROS","PENDIENTE");
        dbHelper.insertarReto("Semana sin compras", "No compres nada que no sea esencial durante 7 días.",  20.0, null, null, "OTROS","PENDIENTE");
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString().trim();
                String balance = balanceEditText.getText().toString().trim();

                if (username.isEmpty()) {
                    usernameEditText.setError("Por favor ingresa tu nombre");
                    return;
                }

                if (balance.isEmpty()) {
                    balanceEditText.setError("Por favor ingresa tu balance");
                    return;
                }

                Toast.makeText(LoginActivity.this, "Bienvenido, " + username + "!", Toast.LENGTH_SHORT).show();

                // Guardar flag de primera vez
                SharedPreferences.Editor editor = prefs.edit();
                editor.putBoolean("isFirstTime", false);
                editor.apply();

                // Ingresar el usaurio a la base de datos junto a su balance
                dbHelper.insertarUsuario("1", username);
                // Ingresar el balance del usuario
                Calendar calendario = Calendar.getInstance(); // Obtener la fecha actual
                dbHelper.insertarPresupuesto(Double.parseDouble(balance), calendario, "1");

                startActivity(new Intent(LoginActivity.this, MainActivity.class));
                finish();
            }
        });
    }
}
