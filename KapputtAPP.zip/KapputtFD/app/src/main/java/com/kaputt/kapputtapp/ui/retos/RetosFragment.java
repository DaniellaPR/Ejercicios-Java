package com.kaputt.kapputtapp.ui.retos;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.kaputt.kapputtapp.DBHelper;
import com.kaputt.kapputtapp.R;
import com.kaputt.kapputtapp.ui.anadir.anadirGasto;
import com.kaputt.kapputtapp.ui.anadir.anadirMeta;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class RetosFragment extends Fragment {

    DBHelper.Reto reto;
    public RetosFragment() {
        // Constructor vacío
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_retos, container, false);
        ImageButton btnAnadirGasto = view.findViewById(R.id.btnAgregarMeta);

        DBHelper dbHelper = new DBHelper(getContext());
        DBHelper.Reto reto = RetoManager.retoSeleccionado;

        TextView txtTitulo = view.findViewById(R.id.tvSubtituloReto);
        TextView txtDescripcion = view.findViewById(R.id.tvDescripcionReto);
        TextView txtEstado = view.findViewById(R.id.tvEstadoReto);
        ProgressBar progressBar = view.findViewById(R.id.progresoReto);

        if (reto != null) {
            txtTitulo.setText(reto.titulo);
            txtDescripcion.setText(reto.descripcion);
            progressBar.setProgress(0); // Inicia en cero

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            try {
                Date fecha = sdf.parse(reto.fecha_ini);
                long inicio = fecha.getTime();
                long ahora = System.currentTimeMillis();
                long unaSemana = 7 * 24 * 60 * 60 * 1000L;

                int progreso = (int) (((ahora - inicio) * 100) / unaSemana);
                progreso = Math.min(progreso, 100);
                progressBar.setProgress(progreso);

                if (progreso >= 100) {
                    txtEstado.setText("¡Completado!");
                    txtEstado.setTextColor(Color.GREEN);
                } else {
                    txtEstado.setText("Aún no cumplido");
                    txtEstado.setTextColor(Color.WHITE); // o el color que uses por defecto
                }
            } catch (ParseException e) {
                e.printStackTrace();  // manejar error si la fecha no tiene el formato correcto
            }


        }

        btnAnadirGasto.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), anadirMeta.class);
            startActivity(intent);
        });
        return view;
    }
}
