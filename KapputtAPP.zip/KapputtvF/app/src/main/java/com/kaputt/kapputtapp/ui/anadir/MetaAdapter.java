package com.kaputt.kapputtapp.ui.anadir;


import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.kaputt.kapputtapp.R;
import com.kaputt.kapputtapp.ui.inicio.Meta;

import java.util.List;

public class MetaAdapter extends RecyclerView.Adapter<MetaAdapter.MetaViewHolder> {

    private List<Meta> listaMetas;

    public MetaAdapter(List<Meta> listaMetas) {
        this.listaMetas = listaMetas;
    }

    @NonNull
    @Override
    public MetaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_meta, parent, false);
        return new MetaViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull MetaViewHolder holder, int position) {
        Meta meta = listaMetas.get(position);
        holder.descripcion.setText(meta.getDescripcion());
        Log.d("ADAPTER", "Meta cargada: " + meta.getDescripcion());
    }

    @Override
    public int getItemCount() {
        return listaMetas.size();
    }

    public static class MetaViewHolder extends RecyclerView.ViewHolder {
        CheckBox checkBox;
        TextView descripcion;
        ImageButton btnEditar, btnBorrar;

        public MetaViewHolder(@NonNull View itemView) {
            super(itemView);
            checkBox = itemView.findViewById(R.id.checkMeta);
            descripcion = itemView.findViewById(R.id.descripcionMeta);

        }
    }
}