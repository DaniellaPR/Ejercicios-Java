package com.kaputt.kapputtapp.ui.anadir;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kaputt.kapputtapp.DBHelper;
import com.kaputt.kapputtapp.R;
import com.kaputt.kapputtapp.ui.inicio.Meta;

import java.util.List;

public class ListaMetasFragment extends Fragment {

    private RecyclerView recyclerView;
    private DBHelper dbHelper;
    private MetaAdapter adapter;
    private String usuId = "1";
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_retos, container, false);
        recyclerView = view.findViewById(R.id.listaMetas);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        dbHelper = new DBHelper(getContext());
        List<Meta> metas = dbHelper.obtenerMetas(usuId);

        adapter = new MetaAdapter(metas);
        recyclerView.setAdapter(adapter);

        return view;
    }
}