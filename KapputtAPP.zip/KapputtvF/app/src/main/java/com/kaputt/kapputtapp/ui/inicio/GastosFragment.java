package com.kaputt.kapputtapp.ui.inicio;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.Toast;



import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.kaputt.kapputtapp.DBHelper;
import com.kaputt.kapputtapp.R;
import com.kaputt.kapputtapp.ui.anadir.anadirGasto;

import java.util.ArrayList;

public class GastosFragment extends Fragment {

    private PieChart pieChart;
    int monto;

    public GastosFragment() {

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_gastos, container, false);

        pieChart = view.findViewById(R.id.pieChart);

        setupPieChart();
        loadPieChartData();


        ImageButton btnAnadirGasto = view.findViewById(R.id.btnAgregarGasto);

        btnAnadirGasto.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), anadirGasto.class);
            startActivity(intent);
        });
        return view;
    }

    private void setupPieChart() {
        pieChart.setUsePercentValues(true);
        pieChart.getDescription().setEnabled(false);
        pieChart.setDrawHoleEnabled(true);
        pieChart.setHoleColor(Color.TRANSPARENT);
        pieChart.setTransparentCircleAlpha(110);
        pieChart.setEntryLabelColor(Color.WHITE);
        pieChart.setCenterText("Gastos");
        pieChart.setCenterTextSize(18f);
        pieChart.setDrawCenterText(true);
        pieChart.animateY(1000, Easing.EaseInOutQuad);

        Legend legend = pieChart.getLegend();
        legend.setEnabled(true);
        legend.setTextColor(Color.WHITE);
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        legend.setDrawInside(false);
    }

    private void loadPieChartData() {
        ArrayList<PieEntry> entries = new ArrayList<>();

        DBHelper dbHelper = new DBHelper(getContext());
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Reemplaza "1" por el ID del usuario real si está disponible
        Cursor cursor = db.rawQuery(
                "SELECT c.CLA_nombre, SUM(g.GAS_monto) as total " +
                        "FROM GASTOS g " +
                        "JOIN CLAS_GASTOS cg ON g.GAS_ID = cg.GAS_ID " +
                        "JOIN CLASIFICACION c ON cg.CLA_ID = c.CLA_ID " +
                        "JOIN PRESUPUESTO p ON g.PRE_ID = p.PRE_ID " +
                        "WHERE p.USU_ID = ? " +
                        "GROUP BY c.CLA_nombre", new String[]{"1"});

        if (cursor.moveToFirst()) {
            do {
                String categoria = cursor.getString(0);
                float total = (float) cursor.getDouble(1);
                entries.add(new PieEntry(total, categoria));
            } while (cursor.moveToNext());
        } else {
            Toast.makeText(getContext(), "No hay datos de gastos", Toast.LENGTH_SHORT).show();
        }

        cursor.close();
        db.close();

        if (entries.isEmpty()) {
            entries.add(new PieEntry(1f, "Sin datos"));
        }

        PieDataSet dataSet = new PieDataSet(entries, "");

        // Asigna colores personalizados para cada categoría
        ArrayList<Integer> colors = new ArrayList<>();
        colors.add(Color.parseColor("#FFA726")); // COMIDA
        colors.add(Color.parseColor("#66BB6A")); // TRANSPORTE
        colors.add(Color.parseColor("#EF5350")); // SALUD_FISICA
        colors.add(Color.parseColor("#AB47BC")); // SALUD_MENTAL
        colors.add(Color.parseColor("#29B6F6")); // OCIO
        colors.add(Color.parseColor("#8D6E63")); // HOGAR
        colors.add(Color.parseColor("#42A5F5")); // EDUCACION
        colors.add(Color.parseColor("#FF7043")); // EJERCICIO
        colors.add(Color.parseColor("#26A69A")); // HOBBIES
        colors.add(Color.parseColor("#BDBDBD")); // OTROS (gris)

        dataSet.setColors(colors);
        dataSet.setValueTextColor(Color.WHITE);
        dataSet.setValueTextSize(14f);

        PieData data = new PieData(dataSet);
        pieChart.setData(data);
        pieChart.invalidate(); // refrescar
    }
}