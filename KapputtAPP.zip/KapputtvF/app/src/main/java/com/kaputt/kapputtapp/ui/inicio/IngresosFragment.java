package com.kaputt.kapputtapp.ui.inicio;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.kaputt.kapputtapp.DBHelper;
import com.kaputt.kapputtapp.R;
import com.kaputt.kapputtapp.ui.anadir.anadirGasto;
import com.kaputt.kapputtapp.ui.anadir.anadirIngreso;

import java.util.ArrayList;

public class IngresosFragment extends Fragment {

    private PieChart pieChart;

    public IngresosFragment() {

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {

        //return inflater.inflate(R.layout.fragment_ingresos, container, false);
        View view = inflater.inflate(R.layout.fragment_ingresos, container, false);
        pieChart = view.findViewById(R.id.pieChart);
        setupPieChart();
        loadPieChartDataFromDB();
        ImageButton btnAnadirGasto = view.findViewById(R.id.btnAgregarIngreso);

        btnAnadirGasto.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), anadirIngreso.class);
            startActivity(intent);
        });
        return view;
    }

    private void setupPieChart() {
        pieChart.setUsePercentValues(true);
        pieChart.getDescription().setEnabled(false);
        pieChart.setDrawHoleEnabled(true);
        pieChart.setHoleColor(Color.TRANSPARENT);
        pieChart.setTransparentCircleAlpha(110);
        pieChart.setEntryLabelColor(Color.WHITE);
        pieChart.setCenterText("Ingresos");
        pieChart.setCenterTextSize(18f);
        pieChart.setDrawCenterText(true);
        pieChart.animateY(1000, Easing.EaseInOutQuad);

        Legend legend = pieChart.getLegend();
        legend.setEnabled(true);
        legend.setTextColor(Color.WHITE);
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        legend.setDrawInside(false);
    }

    private void loadPieChartDataFromDB() {
        ArrayList<PieEntry> entries = new ArrayList<>();

        DBHelper dbHelper = new DBHelper(getContext());
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Consulta: suma montos agrupados por clasificación
        String query = "SELECT ING_clas, SUM(ING_monto) as total " +
                "FROM INGRESOS " +
                "GROUP BY ING_clas";

        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                String clasificacion = cursor.getString(0);
                float total = cursor.getFloat(1);
                entries.add(new PieEntry(total, clasificacion));
            } while (cursor.moveToNext());
        }
        cursor.close();

        if (entries.isEmpty()) {
            // Si no hay datos, agregamos algo por defecto para evitar error en el gráfico
            entries.add(new PieEntry(1f, "Sin datos"));
        }

        PieDataSet dataSet = new PieDataSet(entries, "");
        // Puedes elegir colores diferentes o personalizarlos
        dataSet.setColors(Color.GREEN, Color.MAGENTA, Color.LTGRAY, Color.CYAN, Color.YELLOW);
        dataSet.setValueTextColor(Color.WHITE);
        dataSet.setValueTextSize(14f);

        PieData data = new PieData(dataSet);
        pieChart.setData(data);
        pieChart.invalidate(); // refrescar gráfico
    }
}
