package com.kaputt.kapputtapp.ui.estadisticas;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.graphics.Color;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.google.android.material.tabs.TabLayout;
import com.kaputt.kapputtapp.DBHelper;
import com.kaputt.kapputtapp.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class EstadisticasFragment extends Fragment {

    private BarChart barChart;

    private int tipoSeleccionado = 0;   // 0: General, 1: Gastos, 2: Ingresos
    private int periodoSeleccionado = 0; // 0: Día, 1: Semana, 2: Mes, 3: Año

    public EstadisticasFragment() {

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        //return inflater.inflate(R.layout.fragment_estadisticas, container, false);
        // Inflar el layout del fragmento
        View view = inflater.inflate(R.layout.fragment_estadisticas, container, false);

        // Inicializar BarChart desde la vista inflada
        barChart = view.findViewById(R.id.barChart);

        cargarDatos(); //parte default de la interfaz de estadistica

        // Configurar gráfico base
        configurarGrafico();

        // Obtener referencia al TabLayout de periodos
        TabLayout tabsPeriodo = view.findViewById(R.id.tabsPeriodo);
        TabLayout tabsTipo = view.findViewById(R.id.tabsTipoEstadistica);

        // Escuchar cambios en las pestañas
        tabsPeriodo.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                periodoSeleccionado = tab.getPosition();
                cargarDatos();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}
            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
        tabsTipo.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                tipoSeleccionado = tab.getPosition();
                cargarDatos();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}
            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });

        return view;
    }
    private void configurarGrafico() {
        barChart.setFitBars(true);
        barChart.getDescription().setEnabled(false);
        barChart.animateY(1000);

        YAxis yAxis = barChart.getAxisLeft();
        yAxis.setAxisMinimum(0f); // Siempre empezar desde 0
        yAxis.setAxisMaximum(barChart.getData().getYMax() + 10);

        barChart.getAxisRight().setEnabled(false);

        XAxis xAxis = barChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setDrawGridLines(false);

        barChart.getXAxis().setTextColor(Color.WHITE);
        barChart.getAxisLeft().setTextColor(Color.WHITE);
        barChart.getAxisRight().setTextColor(Color.WHITE);

    }

    private void actualizarGraficoGeneral(ArrayList<BarEntry> entries) {
        BarDataSet dataSet = new BarDataSet(entries, "");
        dataSet.setColors(new int[]{Color.BLUE, Color.RED});
        dataSet.setStackLabels(new String[]{"INGRESO", "GASTOS"});
        String[] categorias = {"Ingreso", "Gastos"};

        XAxis xAxis = barChart.getXAxis();
        xAxis.setGranularity(1f);
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                int index = (int) value;
                return index >= 0 && index < categorias.length ? categorias[index] : "";
            }
        });
        dataSet.setValueTextColor(Color.WHITE);
        barChart.getLegend().setTextColor(Color.WHITE);
        BarData data = new BarData(dataSet);
        data.setBarWidth(0.5f);
        barChart.setData(data);
        barChart.invalidate();
    }
    private void actualizarGraficoGastos(ArrayList<BarEntry> entries) {
        BarDataSet dataSet = new BarDataSet(entries, "");
        dataSet.setColors(new int[]{
                Color.parseColor("#4CAF50"),  // Verde (COMIDA)
                Color.parseColor("#2196F3"),  // Azul (TRANSPORTE)
                Color.parseColor("#FF9800"),  // Naranja (SALUD_FISICA)
                Color.parseColor("#9C27B0"),  // Morado (SALUD_MENTAL)
                Color.parseColor("#F44336"),  // Rojo (OCIO)
                Color.parseColor("#795548"),  // Marrón (HOGAR)
                Color.parseColor("#3F51B5"),  // Azul oscuro (EDUCACION)
                Color.parseColor("#009688"),  // Teal (EJERCICIO)
                Color.parseColor("#FFC107"),  // Ámbar (HOBBIES)
                Color.parseColor("#607D8B")   // Azul grisáceo (OTROS)
        });
        dataSet.setStackLabels(new String[]{"COMIDA", "VIAJE", "SALUD F", "SALUD M", "OCIO", "HOGAR", "LIBRO", "GYM", "HOBBIES", "OTROS"});
        String[] categorias = {"Gastos"};
        dataSet.setValueTextColor(Color.WHITE);
        barChart.getLegend().setTextColor(Color.WHITE);
        barChart.getLegend().setTextSize(3f);
        XAxis xAxis = barChart.getXAxis();
        xAxis.setGranularity(1f);
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                int index = (int) value;
                return index >= 0 && index < categorias.length ? categorias[index] : "";
            }
        });
        BarData data = new BarData(dataSet);
        data.setBarWidth(0.5f);
        barChart.setData(data);
        barChart.invalidate();
    }
    private void actualizarGraficoIngresos(ArrayList<BarEntry> entries) {
        BarDataSet dataSet = new BarDataSet(entries, "");
        dataSet.setColors(new int[]{
                Color.parseColor("#4CAF50"),  // Verde (COMIDA)
                Color.parseColor("#2196F3"),  // Azul (TRANSPORTE)
                Color.parseColor("#3F51B5"),  // Azul oscuro (EDUCACION)
        });
        dataSet.setStackLabels(new String[]{"SALARIO", "EMPRENDIMIENTO", "REGALO"});
        String[] categorias = {"Ingreso"};
        dataSet.setValueTextColor(Color.WHITE);
        barChart.getLegend().setTextColor(Color.WHITE);
        XAxis xAxis = barChart.getXAxis();
        xAxis.setGranularity(1f);
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                int index = (int) value;
                return index >= 0 && index < categorias.length ? categorias[index] : "";
            }
        });
        BarData data = new BarData(dataSet);
        data.setBarWidth(0.5f);
        barChart.setData(data);
        barChart.invalidate();
    }

    private void cargarDatos() {
        ArrayList<BarEntry> entries = new ArrayList<>();
        float[] valores = new float[10];
        float total = 0;
        SimpleDateFormat dateFormat;
        String fecha;
        String query;
        Calendar calendario;
        DBHelper dbHelper;
        SQLiteDatabase db;
        Cursor cursor;
        String fecha_inicio;
        String fecha_fin;
        // Aquí defines tus datos según combinaciones de Tipo y Periodo
        if (tipoSeleccionado == 0) { // GENERAL
            switch (periodoSeleccionado) {
                case 0: // Día
                    calendario = Calendar.getInstance();
                    dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    fecha_fin = dateFormat.format(calendario.getTime());
                    calendario.add(Calendar.DAY_OF_YEAR, -1);
                    fecha_inicio = dateFormat.format(calendario.getTime());
                    dbHelper = new DBHelper(getContext());
                    db = dbHelper.getReadableDatabase();
                    // Consulta: suma montos agrupados por fecha
                    query = "SELECT SUM(ING_monto) as total " +
                            "FROM INGRESOS " +
                            "WHERE ING_Fecha BETWEEN ? AND ?";

                    cursor = db.rawQuery(query, new String[]{fecha_inicio, fecha_fin});

                    if (cursor.moveToFirst()) {
                        do {
                            total += cursor.getFloat(0);
                        } while (cursor.moveToNext());
                    }
                    cursor.close();
                    entries.add(new BarEntry(0f, total));
                    total = 0;
                    dbHelper = new DBHelper(getContext());
                    db = dbHelper.getReadableDatabase();
                    // Consulta: suma montos agrupados por fecha
                    query = "SELECT SUM(GAS_monto) as total " +
                            "FROM GASTOS " +
                            "WHERE GAS_Fecha BETWEEN ? AND ?";

                    cursor = db.rawQuery(query, new String[]{fecha_inicio, fecha_fin});
                    if (cursor.moveToFirst()) {
                        do {
                            total += cursor.getFloat(0);
                        } while (cursor.moveToNext());
                    }
                    entries.add(new BarEntry(1f, total));
                    break;
                case 1: // Semana
                    calendario = Calendar.getInstance();
                    dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    fecha_fin = dateFormat.format(calendario.getTime());
                    calendario.add(Calendar.DAY_OF_YEAR, -6);
                    fecha_inicio = dateFormat.format(calendario.getTime());
                    dbHelper = new DBHelper(getContext());
                    db = dbHelper.getReadableDatabase();
                    // Consulta de INGRESOS en los últimos 7 días
                    query = "SELECT SUM(ING_monto) as total " +
                            "FROM INGRESOS " +
                            "WHERE ING_Fecha BETWEEN ? AND ?";

                    cursor = db.rawQuery(query, new String[]{fecha_inicio, fecha_fin});
                    if (cursor.moveToFirst()) {
                        total = cursor.getFloat(0);
                    }
                    cursor.close();
                    entries.add(new BarEntry(0f, total));
                    total = 0;

                    // Consulta de GASTOS en los últimos 7 días
                    query = "SELECT SUM(GAS_monto) as total " +
                            "FROM GASTOS " +
                            "WHERE GAS_Fecha BETWEEN ? AND ?";

                    cursor = db.rawQuery(query, new String[]{fecha_inicio, fecha_fin});
                    if (cursor.moveToFirst()) {
                        total = cursor.getFloat(0);
                    }
                    cursor.close();
                    db.close();

                    entries.add(new BarEntry(1f, total));
                    break;
                case 2: // Mes
                    calendario = Calendar.getInstance();
                    dateFormat = new SimpleDateFormat("yyyy-MM"); // Solo año-mes
                    String mesActual = dateFormat.format(calendario.getTime()); // Ej: "2025-07"

                    dbHelper = new DBHelper(getContext());
                    db = dbHelper.getReadableDatabase();

                    // Consulta de INGRESOS del mes actual
                    query = "SELECT SUM(ING_monto) as total " +
                            "FROM INGRESOS " +
                            "WHERE strftime('%Y-%m', ING_Fecha) = ?";
                    cursor = db.rawQuery(query, new String[]{mesActual});
                    if (cursor.moveToFirst()) {
                        total = cursor.getFloat(0);
                    }
                    cursor.close();
                    entries.add(new BarEntry(0f, total));
                    total = 0;

                    // Consulta de GASTOS del mes actual
                    query = "SELECT SUM(GAS_monto) as total " +
                            "FROM GASTOS " +
                            "WHERE strftime('%Y-%m', GAS_Fecha) = ?";
                    cursor = db.rawQuery(query, new String[]{mesActual});
                    if (cursor.moveToFirst()) {
                        total = cursor.getFloat(0);
                    }
                    cursor.close();
                    db.close();

                    entries.add(new BarEntry(1f, total));
                    break;

                case 3: // Año
                    calendario = Calendar.getInstance();
                    dateFormat = new SimpleDateFormat("yyyy"); // Solo año
                    String anioActual = dateFormat.format(calendario.getTime()); // Ej: "2025"

                    dbHelper = new DBHelper(getContext());
                    db = dbHelper.getReadableDatabase();

                    // Consulta de INGRESOS del año actual
                    query = "SELECT SUM(ING_monto) as total " +
                            "FROM INGRESOS " +
                            "WHERE strftime('%Y', ING_Fecha) = ?";
                    cursor = db.rawQuery(query, new String[]{anioActual});
                    if (cursor.moveToFirst()) {
                        total = cursor.getFloat(0);
                    }
                    cursor.close();
                    entries.add(new BarEntry(0f, total));
                    total = 0;

                    // Consulta de GASTOS del año actual
                    query = "SELECT SUM(GAS_monto) as total " +
                            "FROM GASTOS " +
                            "WHERE strftime('%Y', GAS_Fecha) = ?";
                    cursor = db.rawQuery(query, new String[]{anioActual});
                    if (cursor.moveToFirst()) {
                        total = cursor.getFloat(0);
                    }
                    cursor.close();
                    db.close();

                    entries.add(new BarEntry(1f, total));
                    break;
            }
            actualizarGraficoGeneral(entries);
        } else if (tipoSeleccionado == 1) { // GASTOS
            switch (periodoSeleccionado) {
                case 0:
                    dbHelper = new DBHelper(getContext());
                    calendario = Calendar.getInstance();
                    dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    fecha_fin = dateFormat.format(calendario.getTime());
                    calendario.add(Calendar.DAY_OF_YEAR, -1);
                    fecha_inicio = dateFormat.format(calendario.getTime());
                    valores = dbHelper.gastosPorFecha(fecha_inicio, fecha_fin);
                    entries.add(new BarEntry(0f, valores));
                    break;
                case 1:
                    dbHelper = new DBHelper(getContext());
                    calendario = Calendar.getInstance();
                    dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    fecha_fin = dateFormat.format(calendario.getTime());
                    calendario.add(Calendar.DAY_OF_YEAR, -6);
                    fecha_inicio = dateFormat.format(calendario.getTime());
                    valores = dbHelper.gastosPorFecha(fecha_inicio, fecha_fin);
                    entries.add(new BarEntry(0f, valores));
                    break;
                case 2:
                    calendario = Calendar.getInstance();
                    dateFormat = new SimpleDateFormat("yyyy-MM"); // Solo año-mes
                    String mesActual = dateFormat.format(calendario.getTime()); // Ej: "2025-07"
                    dbHelper = new DBHelper(getContext());
                    db = dbHelper.getReadableDatabase();
                    valores = dbHelper.gastosPorMes(mesActual);
                    entries.add(new BarEntry(0f, valores));
                    break;
                case 3:
                    calendario = Calendar.getInstance();
                    dateFormat = new SimpleDateFormat("yyyy"); // Solo año
                    String anioActual = dateFormat.format(calendario.getTime()); // Ej: "2025"
                    dbHelper = new DBHelper(getContext());
                    db = dbHelper.getReadableDatabase();
                    valores = dbHelper.gastosPorAnio(anioActual);
                    entries.add(new BarEntry(0f, valores));
                    break;
            }
            actualizarGraficoGastos(entries);
        } else if (tipoSeleccionado == 2) { // INGRESOS
            switch (periodoSeleccionado) {
                case 0:
                    dbHelper = new DBHelper(getContext());
                    calendario = Calendar.getInstance();
                    dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    fecha_fin = dateFormat.format(calendario.getTime());
                    calendario.add(Calendar.DAY_OF_YEAR, -1);
                    fecha_inicio = dateFormat.format(calendario.getTime());
                    valores = dbHelper.ingresosPorFecha(fecha_inicio, fecha_fin);
                    entries.add(new BarEntry(0f, valores));
                    break;
                case 1:
                    dbHelper = new DBHelper(getContext());
                    calendario = Calendar.getInstance();
                    dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    fecha_fin = dateFormat.format(calendario.getTime());
                    calendario.add(Calendar.DAY_OF_YEAR, -6);
                    fecha_inicio = dateFormat.format(calendario.getTime());
                    valores = dbHelper.ingresosPorFecha(fecha_inicio, fecha_fin);
                    entries.add(new BarEntry(0f, valores));
                    break;
                case 2:
                    calendario = Calendar.getInstance();
                    dateFormat = new SimpleDateFormat("yyyy-MM"); // Solo año-mes
                    String mesActual = dateFormat.format(calendario.getTime()); // Ej: "2025-07"
                    dbHelper = new DBHelper(getContext());
                    db = dbHelper.getReadableDatabase();
                    valores = dbHelper.ingresosPorMes(mesActual);
                    entries.add(new BarEntry(0f, valores));
                    break;
                case 3:
                    calendario = Calendar.getInstance();
                    dateFormat = new SimpleDateFormat("yyyy"); // Solo año
                    String anioActual = dateFormat.format(calendario.getTime()); // Ej: "2025"
                    dbHelper = new DBHelper(getContext());
                    db = dbHelper.getReadableDatabase();
                    valores = dbHelper.ingresosPorAnio(anioActual);
                    entries.add(new BarEntry(0f, valores));
                    break;
            }
            actualizarGraficoIngresos(entries);
        }
    }

}
