package com.kaputt.kapputtapp.ui.anadir;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.kaputt.kapputtapp.DBHelper;
import com.kaputt.kapputtapp.MainActivity;
import com.kaputt.kapputtapp.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class anadirIngreso extends AppCompatActivity {

    String descripcion, tipo, fecha, monto;
    private EditText montoText;
    private EditText descripcionText;
    private Button salarioButton;
    private Button emprendimientoButton;
    private Button regaloButton;
    private Button hoyButton;
    private Button manianaButton;
    private Button calendarioButton;
    private Button agregarButton;
    private Button regresarButton;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        DBHelper dbHelper = new DBHelper(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_add_ingreso);

        // Fecha
        hoyButton = findViewById(R.id.btnHoyIngreso);
        manianaButton = findViewById(R.id.btnManianaIngreso);
        calendarioButton = findViewById(R.id.btnCalendarioIngreso);
        // Tipo ingreso
        salarioButton = findViewById(R.id.btnSalario);
        emprendimientoButton = findViewById(R.id.btnEmprendimiento);
        regaloButton = findViewById(R.id.btnRegalo);
        // EditText
        montoText = findViewById(R.id.etMontoIngreso);
        descripcionText = findViewById(R.id.etComentarioIngreso);

        agregarButton = findViewById(R.id.btnAceptarIngreso);
        regresarButton = findViewById(R.id.VolverAddIngreso);


        // fecha
        calendarioButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendario = Calendar.getInstance();
                int year = calendario.get(Calendar.YEAR);
                int month = calendario.get(Calendar.MONTH);
                int day = calendario.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        anadirIngreso.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                Calendar seleccionada = Calendar.getInstance();
                                seleccionada.set(year, monthOfYear, dayOfMonth);
                                SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
                                fecha = formato.format(seleccionada.getTime());

                                Toast.makeText(anadirIngreso.this, "Fecha seleccionada: " + fecha, Toast.LENGTH_SHORT).show();
                            }
                        },
                        year, month, day
                );

                // Restringir fecha mínima a hoy
                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis());
                datePickerDialog.show();
            }
        });
        hoyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendario = Calendar.getInstance(); // Obtener la fecha actual
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                fecha = dateFormat.format(calendario.getTime());
                Toast.makeText(anadirIngreso.this, "Fecha seleccionada: " + fecha, Toast.LENGTH_SHORT).show();
            }
        });
        manianaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendario = Calendar.getInstance(); // Obtener la fecha actual
                calendario.add(Calendar.DAY_OF_MONTH, 1);
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                fecha = dateFormat.format(calendario.getTime());
                Toast.makeText(anadirIngreso.this, "Fecha seleccionada: " + fecha, Toast.LENGTH_SHORT).show();
            }
        });

        // Tipo
        salarioButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tipo = "SALARIO";
                Toast.makeText(anadirIngreso.this, "Tipo de ingreso 'Salario' seleccionado", Toast.LENGTH_SHORT).show();
            }
        });
        emprendimientoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tipo = "EMPRENDIMIENTO";
                Toast.makeText(anadirIngreso.this, "Tipo de ingreso 'Emprendimiento' seleccionado", Toast.LENGTH_SHORT).show();
            }
        });
        regaloButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tipo = "REGALO";
                Toast.makeText(anadirIngreso.this, "Tipo de ingreso 'Regalo' seleccionado", Toast.LENGTH_SHORT).show();
            }
        });

        agregarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean valido = true;
                monto = montoText.getText().toString().trim();
                descripcion = descripcionText.getText().toString().trim();
                if (monto.isEmpty()){
                    montoText.setError("Por favor ingresa un monto");
                    valido = false;
                }
                if (descripcion.isEmpty()){
                    descripcionText.setError("Por favor ingresa una descripción");
                    valido = false;
                }
                if (tipo == null){
                    Toast.makeText(anadirIngreso.this, "Por favor selecciona un tipo", Toast.LENGTH_SHORT).show();
                    valido = false;
                }
                if (fecha == null){
                    Toast.makeText(anadirIngreso.this, "Por favor selecciona una fecha", Toast.LENGTH_SHORT).show();
                    valido = false;
                }
                if (valido){
                    if (dbHelper.insertarIngreso(Double.parseDouble(monto), descripcion, fecha, tipo)){
                        Toast.makeText(anadirIngreso.this, "Ingreso añadido exitosamente", Toast.LENGTH_SHORT).show();
                        fecha = null;
                        tipo = null;
                        montoText.setText(null);
                        descripcionText.setText(null);
                    }
                }
            }
        });

        regresarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent volverIntent = new Intent(anadirIngreso.this, MainActivity.class);
                startActivity(volverIntent);
                finish();
            }
        });
    }
}
