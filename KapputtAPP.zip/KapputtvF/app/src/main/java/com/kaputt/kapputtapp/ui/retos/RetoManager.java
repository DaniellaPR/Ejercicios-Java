package com.kaputt.kapputtapp.ui.retos;

import com.kaputt.kapputtapp.DBHelper;

public class RetoManager {
    public static DBHelper.Reto retoSeleccionado;

}
