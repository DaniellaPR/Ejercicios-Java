package com.example.kapput;

public class Detalle_consulta {
}
