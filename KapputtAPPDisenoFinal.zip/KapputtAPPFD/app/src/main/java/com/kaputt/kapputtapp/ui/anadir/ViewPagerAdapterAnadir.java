package com.kaputt.kapputtapp.ui.anadir;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class ViewPagerAdapterAnadir extends FragmentStateAdapter {

    public ViewPagerAdapterAnadir(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        if (position == 0) {
            return new anadirGasto();
        } else {
            return new anadirIngreso();
        }
    }

    @Override
    public int getItemCount() {
        return 2;}
}
