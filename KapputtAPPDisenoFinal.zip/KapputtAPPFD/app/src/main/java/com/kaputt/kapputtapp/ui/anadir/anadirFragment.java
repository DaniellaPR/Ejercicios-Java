package com.kaputt.kapputtapp.ui.anadir;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.kaputt.kapputtapp.R;

public class anadirFragment extends Fragment {

    private static final String ARG_TAB_INDEX = "tab_index";

    public static anadirFragment newInstance(int tabIndex) {
        anadirFragment fragment = new anadirFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_TAB_INDEX, tabIndex);
        fragment.setArguments(args);
        return fragment;
    }

    public anadirFragment() {}

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_anadir, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view,
                              @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TabLayout tabLayout = view.findViewById(R.id.tabLayout);
        ViewPager2 viewPager = view.findViewById(R.id.viewPager);

        ViewPagerAdapterAnadir adapter = new ViewPagerAdapterAnadir(requireActivity());
        viewPager.setAdapter(adapter);

        new TabLayoutMediator(tabLayout, viewPager,
                (tab, position) -> {
                    if (position == 0) {
                        tab.setText("Gasto");
                    } else {
                        tab.setText("Ingreso");
                    }
                }).attach();


        int tabIndex = getArguments() != null ? getArguments().getInt(ARG_TAB_INDEX, 0) : 0;
        viewPager.setCurrentItem(tabIndex,false);}
}