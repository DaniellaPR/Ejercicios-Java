package com.kaputt.kapputtapp.ui.estadisticas;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.graphics.Color;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.android.material.tabs.TabLayout;
import com.kaputt.kapputtapp.R;

import java.util.ArrayList;
import java.util.List;

public class EstadisticasFragment extends Fragment {

    private BarChart barChart;

    private int tipoSeleccionado = 0;   // 0: General, 1: Gastos, 2: Ingresos
    private int periodoSeleccionado = 0; // 0: Día, 1: Semana, 2: Mes, 3: Año

    public EstadisticasFragment() {

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        //return inflater.inflate(R.layout.fragment_estadisticas, container, false);
        // Inflar el layout del fragmento
        View view = inflater.inflate(R.layout.fragment_estadisticas, container, false);

        // Inicializar BarChart desde la vista inflada
        barChart = view.findViewById(R.id.barChart);

        cargarDatos(); //parte default de la interfaz de estadistica

        // Configurar gráfico base
        configurarGrafico();

        // Obtener referencia al TabLayout de periodos
        TabLayout tabsPeriodo = view.findViewById(R.id.tabsPeriodo);
        TabLayout tabsTipo = view.findViewById(R.id.tabsTipoEstadistica);

        // Escuchar cambios en las pestañas
        tabsPeriodo.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                periodoSeleccionado = tab.getPosition();
                cargarDatos();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}
            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
        tabsTipo.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                tipoSeleccionado = tab.getPosition();
                cargarDatos();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}
            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });

        return view;
    }
    private void configurarGrafico() {
        barChart.setFitBars(true);
        barChart.getDescription().setEnabled(false);
        barChart.animateY(1000);

        YAxis yAxis = barChart.getAxisLeft();
        yAxis.setAxisMinimum(0f);
        yAxis.setAxisMaximum(30f);

        barChart.getAxisRight().setEnabled(false);

        XAxis xAxis = barChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setDrawGridLines(false);
    }

    private void actualizarGraficoGeneral(ArrayList<BarEntry> entries) {
        BarDataSet dataSet = new BarDataSet(entries, "Barras segmentadas");
        dataSet.setColors(new int[]{Color.BLUE, Color.RED, Color.CYAN, Color.YELLOW});
        dataSet.setStackLabels(new String[]{"Ingreso", "Gastos", "Beneficio", "Perdida"});

        BarData data = new BarData(dataSet);
        data.setBarWidth(0.5f);
        barChart.setData(data);
        barChart.invalidate();
    }

    private void actualizarGraficoIngresoGastos(ArrayList<BarEntry> entries) {
        BarDataSet dataSet = new BarDataSet(entries, "Barras segmentadas");
        dataSet.setColors(new int[]{Color.BLUE, Color.RED, Color.YELLOW});
        dataSet.setStackLabels(new String[]{"Ingreso", "Gastos", "Otro"});

        BarData data = new BarData(dataSet);
        data.setBarWidth(0.5f);
        barChart.setData(data);
        barChart.invalidate();
    }

    private void cargarDatos() {
        ArrayList<BarEntry> entries = new ArrayList<>();

        // Aquí defines tus datos según combinaciones de Tipo y Periodo
        if (tipoSeleccionado == 0) { // GENERAL
            switch (periodoSeleccionado) {
                case 0: // Día
                    entries.add(new BarEntry(0f, new float[]{5f}));
                    entries.add(new BarEntry(1f, new float[]{3f}));
                    entries.add(new BarEntry(2f, new float[]{4f}));
                    entries.add(new BarEntry(3f, new float[]{4f}));
                    break;
                case 1: // Semana
                    entries.add(new BarEntry(0f, new float[]{6f}));
                    entries.add(new BarEntry(1f, new float[]{2f}));
                    entries.add(new BarEntry(2f, new float[]{7f}));
                    entries.add(new BarEntry(3f, new float[]{4f}));
                    break;
                case 2: // Mes
                    entries.add(new BarEntry(0f, new float[]{8f}));
                    entries.add(new BarEntry(1f, new float[]{6f}));
                    entries.add(new BarEntry(2f, new float[]{7f}));
                    entries.add(new BarEntry(3f, new float[]{4f}));
                    break;
                case 3: // Año
                    entries.add(new BarEntry(0f, new float[]{10f}));
                    entries.add(new BarEntry(1f, new float[]{8f}));
                    entries.add(new BarEntry(2f, new float[]{9f}));
                    entries.add(new BarEntry(3f, new float[]{4f}));
                    break;
            }
            actualizarGraficoGeneral(entries);
        } else if (tipoSeleccionado == 1) { // GASTOS
            switch (periodoSeleccionado) {
                case 0: entries.add(new BarEntry(0f, new float[]{3f, 10f, 5f})); break;
                case 1: entries.add(new BarEntry(0f, new float[]{2f, 15f, 3f})); break;
                case 2: entries.add(new BarEntry(0f, new float[]{1f, 20f, 2f})); break;
                case 3: entries.add(new BarEntry(0f, new float[]{5f, 25f, 1f})); break;
            }
            actualizarGraficoIngresoGastos(entries);
        } else if (tipoSeleccionado == 2) { // INGRESOS
            switch (periodoSeleccionado) {
                case 0: entries.add(new BarEntry(0f, new float[]{10f, 6f, 2f})); break;
                case 1: entries.add(new BarEntry(0f, new float[]{15f, 7f, 4f})); break;
                case 2: entries.add(new BarEntry(0f, new float[]{20f, 8f, 1f})); break;
                case 3: entries.add(new BarEntry(0f, new float[]{25f, 9f, 3f})); break;
            }
            actualizarGraficoIngresoGastos(entries);
        }
    }

}
