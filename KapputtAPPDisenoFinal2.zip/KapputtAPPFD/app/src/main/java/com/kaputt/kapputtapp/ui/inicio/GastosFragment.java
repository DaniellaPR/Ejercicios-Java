package com.kaputt.kapputtapp.ui.inicio;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;



import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.kaputt.kapputtapp.R;

import java.util.ArrayList;

public class GastosFragment extends Fragment {

    private PieChart pieChart;
    int monto;

    public GastosFragment() {

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_gastos, container, false);

        pieChart = view.findViewById(R.id.pieChart);

        setupPieChart();
        loadPieChartData();

        return view;
    }

    private void setupPieChart() {
        pieChart.setUsePercentValues(true);
        pieChart.getDescription().setEnabled(false);
        pieChart.setDrawHoleEnabled(true);
        pieChart.setHoleColor(Color.TRANSPARENT);
        pieChart.setTransparentCircleAlpha(110);
        pieChart.setEntryLabelColor(Color.WHITE);
        pieChart.setCenterText("Gastos");
        pieChart.setCenterTextSize(18f);
        pieChart.setDrawCenterText(true);
        pieChart.animateY(1000, Easing.EaseInOutQuad);

        Legend legend = pieChart.getLegend();
        legend.setEnabled(true);
        legend.setTextColor(Color.WHITE);
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        legend.setDrawInside(false);
    }

    private void loadPieChartData() {
        ArrayList<PieEntry> entries = new ArrayList<>();
        entries.add(new PieEntry(150f, "Alquiler"));
        entries.add(new PieEntry(80f, "Comida"));
        entries.add(new PieEntry(40f, "Transporte"));
        entries.add(new PieEntry(40f, "Otros"));

        PieDataSet dataSet = new PieDataSet(entries, "Categorías");
        dataSet.setColors(Color.RED, Color.BLUE, Color.YELLOW, Color.CYAN);
        dataSet.setValueTextColor(Color.WHITE);
        dataSet.setValueTextSize(14f);

        PieData data = new PieData(dataSet);
        pieChart.setData(data);
        pieChart.invalidate(); // refrescar
    }
    public void consultaGasto(View v) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(getContext(),
                "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        String ID = "a";
                //et1.getText().toString(); // Se debe de cambiar por el ID de usuario

        Cursor fila = bd.rawQuery(
                "SELECT cla_nombre,gas_monto" +
                        " FROM usuario u" +
                        " JOIN presupuesto p ON u.USU_ID = p.USU_ID"+
                        " JOIN gastos g ON p.PRE_ID = g.PRE_ID" +
                        " JOIN clasif_gatsos cg ON g.GAS_ID = cg.GAS_ID" +
                        " JOIN clasificacion c ON cg.CLA_ID = c.CLA_ID" +
                        " WHERE u.USU_ID = " + ID, null);


    }
}