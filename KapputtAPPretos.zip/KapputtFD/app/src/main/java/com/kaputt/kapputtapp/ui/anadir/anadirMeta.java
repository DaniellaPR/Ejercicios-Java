package com.kaputt.kapputtapp.ui.anadir;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.kaputt.kapputtapp.MainActivity;
import com.kaputt.kapputtapp.R;

public class anadirMeta extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_anadir_meta);

        Button btnVolver = findViewById(R.id.btnGuardarMeta);
        btnVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent volverIntent = new Intent(anadirMeta.this, MainActivity.class);
                startActivity(volverIntent);
                finish();
            }
        });
        Button btnVolver2 = findViewById(R.id.button5);
        btnVolver2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent volverIntent = new Intent(anadirMeta.this, MainActivity.class);
                startActivity(volverIntent);
                finish();
            }
        });
    }
}
