package com.kaputt.kapputtapp.ui.anadir;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.kaputt.kapputtapp.DBHelper;
import com.kaputt.kapputtapp.MainActivity;
import com.kaputt.kapputtapp.R;

import java.util.Calendar;
import java.text.SimpleDateFormat;


public class anadirGasto extends AppCompatActivity {

    String fecha, categoria, descipcion, monto;
    private ImageButton comidaButton;
    private ImageButton transporteButton;
    private ImageButton sFisicaButton;
    private ImageButton sMentalButton;
    private ImageButton ocioButton;
    private ImageButton hogarButton;
    private ImageButton educacionButton;
    private ImageButton ejercicioButton;
    private ImageButton hobbiesButton;
    private ImageButton otroButton;
    private Button hoyButton;
    private Button manianaButton;
    private Button calendarioButton;
    private Button aniadirGasto;
    private Button regresarButton;
    private EditText montoEditText;
    private EditText descripcionEditText;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        DBHelper dbHelper = new DBHelper(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_add_gasto);

        // Fechas
        calendarioButton = findViewById(R.id.btnCalendarioIngreso);
        hoyButton = findViewById(R.id.btnHoyIngreso);
        manianaButton = findViewById(R.id.btnManianaIngreso);

        // Categoria
        comidaButton = findViewById(R.id.btnCategoriaComida);
        transporteButton = findViewById(R.id.btnCategoriaTransporte);
        sFisicaButton = findViewById(R.id.btnCategoriaSaludFisica);
        sMentalButton = findViewById(R.id.btnCategoriaSaludMental);
        ocioButton = findViewById(R.id.btnCategoriaOcio);
        hogarButton = findViewById(R.id.btnCategoriaHogar);
        educacionButton = findViewById(R.id.btnCategoriaEducacion);
        ejercicioButton = findViewById(R.id.btnCategoriaEjercicio);
        hobbiesButton = findViewById(R.id.btnCategoriaHobbies);
        otroButton = findViewById(R.id.btnCategoriaOtro);

        aniadirGasto = findViewById(R.id.ConfAnadirGasto);
        regresarButton = findViewById(R.id.volverAddGasto);

        montoEditText = findViewById(R.id.etMontoGasto);
        descripcionEditText = findViewById(R.id.etComentarioIngreso);

        // fecha
        calendarioButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendario = Calendar.getInstance();
                int year = calendario.get(Calendar.YEAR);
                int month = calendario.get(Calendar.MONTH);
                int day = calendario.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        anadirGasto.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                Calendar seleccionada = Calendar.getInstance();
                                seleccionada.set(year, monthOfYear, dayOfMonth);
                                SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
                                fecha = formato.format(seleccionada.getTime());

                                Toast.makeText(anadirGasto.this, "Fecha seleccionada: " + fecha, Toast.LENGTH_SHORT).show();
                            }
                        },
                        year, month, day
                );

                // Restringir fecha mínima a hoy
                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis());
                datePickerDialog.show();
            }
        });
        hoyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendario = Calendar.getInstance(); // Obtener la fecha actual
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                fecha = dateFormat.format(calendario.getTime());
                Toast.makeText(anadirGasto.this, "Fecha seleccionada: " + fecha, Toast.LENGTH_SHORT).show();
            }
        });
        manianaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendario = Calendar.getInstance(); // Obtener la fecha actual
                calendario.add(Calendar.DAY_OF_MONTH, 1);
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                fecha = dateFormat.format(calendario.getTime());
                Toast.makeText(anadirGasto.this, "Fecha seleccionada: " + fecha, Toast.LENGTH_SHORT).show();
            }
        });

        // Categoria
        comidaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                categoria = "COMIDA";
                Toast.makeText(anadirGasto.this, "Catergoria 'Comida' seleccionada", Toast.LENGTH_SHORT).show();
            }
        });
        transporteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                categoria = "TRANSPORTE";
                Toast.makeText(anadirGasto.this, "Catergoria 'Transporte' seleccionada", Toast.LENGTH_SHORT).show();
            }
        });
        sFisicaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                categoria = "SALUD_FISICA";
                Toast.makeText(anadirGasto.this, "Catergoria 'Salud Física' seleccionada", Toast.LENGTH_SHORT).show();
            }
        });
        sMentalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                categoria = "SALUD_MENTAL";
                Toast.makeText(anadirGasto.this, "Catergoria 'Salud Mental' seleccionada", Toast.LENGTH_SHORT).show();
            }
        });
        ocioButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                categoria = "OCIO";
                Toast.makeText(anadirGasto.this, "Catergoria 'Ocio' seleccionada", Toast.LENGTH_SHORT).show();
            }
        });
        hogarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                categoria = "HOGAR";
                Toast.makeText(anadirGasto.this, "Catergoria 'Hogar' seleccionada", Toast.LENGTH_SHORT).show();
            }
        });
        educacionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                categoria = "EDUCACION";
                Toast.makeText(anadirGasto.this, "Catergoria 'Educación' seleccionada", Toast.LENGTH_SHORT).show();
            }
        });
        ejercicioButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                categoria = "EJERCICIO";
                Toast.makeText(anadirGasto.this, "Catergoria 'Ejercicio' seleccionada", Toast.LENGTH_SHORT).show();
            }
        });
        hobbiesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                categoria = "HOBBIES";
                Toast.makeText(anadirGasto.this, "Catergoria 'Hobbies' seleccionada", Toast.LENGTH_SHORT).show();
            }
        });
        otroButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                categoria = "OTRO";
                Toast.makeText(anadirGasto.this, "Catergoria 'Otro' seleccionada", Toast.LENGTH_SHORT).show();
            }

        });


        // Añadir
        aniadirGasto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean valido = true;
                monto = montoEditText.getText().toString().trim();
                descipcion = descripcionEditText.getText().toString().trim();
                if (monto.isEmpty()){
                    montoEditText.setError("Por favor ingresa un monto");
                    valido = false;
                }
                if (descipcion.isEmpty()){
                    descripcionEditText.setError("Por favor ingresa una descripción");
                    valido = false;
                }
                if (categoria == null){
                    Toast.makeText(anadirGasto.this, "Por favor selecciona una categoria", Toast.LENGTH_SHORT).show();
                    valido = false;
                }
                if (fecha == null){
                    Toast.makeText(anadirGasto.this, "Por favor selecciona una opción para la fecha", Toast.LENGTH_SHORT).show();
                    valido = false;
                }
                // Añadir gasto
                if (valido){
                    if (dbHelper.insertarGasto(Double.parseDouble(monto), descipcion, fecha, categoria)){
                        Toast.makeText(anadirGasto.this, "Gasto añadido exitosamente", Toast.LENGTH_SHORT).show();
                        categoria = null;
                        fecha = null;
                        montoEditText.setText(null);
                        descripcionEditText.setText(null);

                    }
                }
            }
        });

        regresarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent volverIntent = new Intent(anadirGasto.this, MainActivity.class);
                startActivity(volverIntent);
                finish();
            }
        });
    }
}
