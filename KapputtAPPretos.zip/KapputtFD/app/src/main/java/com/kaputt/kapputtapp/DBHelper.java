package com.kaputt.kapputtapp;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.Calendar;
import java.text.SimpleDateFormat;

public class DBHelper extends SQLiteOpenHelper{
    private static final String DB_NAME = "KaputtDB.db";
    private static final int DB_VERSION = 13;


    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Usuario
        db.execSQL("CREATE TABLE USUARIO (" +
                "USU_ID TEXT PRIMARY KEY, " +
                "USU_nombre TEXT NOT NULL)");

        // Clasificación
        db.execSQL("CREATE TABLE CLASIFICACION (" +
                "CLA_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "CLA_nombre TEXT, " +
                "CLA_descr TEXT)");

        // Presupuesto
        db.execSQL("CREATE TABLE PRESUPUESTO (" +
                "PRE_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "PRE_monto REAL NOT NULL, " +
                "PRE_FechaIn TEXT NOT NULL, " +
                "PRE_FechaFn TEXT NOT NULL, " +
                "USU_ID TEXT NOT NULL, " +
                "FOREIGN KEY (USU_ID) REFERENCES USUARIO(USU_ID))");

        // Meta
        db.execSQL("CREATE TABLE META (" +
                "MET_idMeta INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "MET_nombre TEXT NOT NULL, " +
                "MET_descrip TEXT, " +
                "MET_valor REAL,"+
                "USU_ID TEXT NOT NULL, " +
                "FOREIGN KEY (USU_ID) REFERENCES USUARIO(USU_ID))");

        // Retos
        db.execSQL("CREATE TABLE RETOS (" +
                "RET_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "RET_nombre TEXT NOT NULL, " +
                "RET_descrip TEXT, " +
                "RET_valor REAL," +
                "RET_fecha_in TEXT," +
                "RET_fecha_fin TEXT," +
                "RET_cat_asociada TEXT," +
                "RET_estado TEXT)");

        // Ingresos
        db.execSQL("CREATE TABLE INGRESOS (" +
                "ING_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "ING_monto REAL NOT NULL, " +
                "ING_desc TEXT, " +
                "ING_clas TEXT," +
                "ING_Fecha TEXT NOT NULL, " +
                "PRE_ID INTEGER NOT NULL, " +
                "FOREIGN KEY (PRE_ID) REFERENCES PRESUPUESTO(PRE_ID))");

        // Gastos
        db.execSQL("CREATE TABLE GASTOS (" +
                "GAS_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "GAS_monto REAL NOT NULL, " +
                "GAS_desc TEXT, " +
                "GAS_Fecha TEXT NOT NULL, " +
                "PRE_ID INTEGER NOT NULL, " +
                "FOREIGN KEY (PRE_ID) REFERENCES PRESUPUESTO(PRE_ID))");

        // Tabla intermedia
        db.execSQL("CREATE TABLE CLAS_GASTOS (" +
                "GAS_ID INTEGER, " +
                "CLA_ID INTEGER, " +
                "PRIMARY KEY (GAS_ID, CLA_ID), " +
                "FOREIGN KEY (GAS_ID) REFERENCES GASTOS(GAS_ID), " +
                "FOREIGN KEY (CLA_ID) REFERENCES CLASIFICACION(CLA_ID))");


    }

    // Usuario
    public boolean insertarUsuario(String id, String nombre) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put("USU_ID", id);
        valores.put("USU_nombre", nombre);
        long resultado = db.insert("USUARIO", null, valores);
        return resultado != -1;
    }

    // Meta
    public boolean insertarMeta(String nombre, String descrip, String usuId,@Nullable Double valor) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put("MET_nombre", nombre);
        valores.put("MET_descrip", descrip);
        valores.put("USU_ID", usuId);
        valores.put("MET_valor", valor);
        long resultado = db.insert("META", null, valores);
        return resultado != -1;
    }
    public boolean insertarMeta(String nombre, String descrip, String usuId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put("MET_nombre", nombre);
        valores.put("MET_descrip", descrip);
        valores.put("USU_ID", usuId);
        long resultado = db.insert("META", null, valores);
        return resultado != -1;
    }

    // Retos
    public boolean insertarReto(String nombre, String descrip, @Nullable  Double valor,@Nullable String fecha_in, @Nullable String fecha_fin, @Nullable String categoria,@Nullable String estado) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put("RET_nombre", nombre);
        valores.put("RET_descrip", descrip);
        valores.put("RET_valor", valor);
        valores.put("RET_fecha_in",fecha_in);
        valores.put("RET_fecha_fin",fecha_fin);
        valores.put("RET_cat_asociada",categoria);
        valores.put("RET_estado",estado);
        long resultado = db.insert("RETOS", null, valores);
        return resultado != -1;
    }



    // Presupuesto
    public int insertarPresupuesto(double monto, Calendar calendario, String usuId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues valores = new ContentValues();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cTemp = calendario;
        int ID = 0;
        int ultimoDia = calendario.getMaximum(Calendar.DAY_OF_MONTH); // Obtener el valor del último día del mes

        // Obtener primer día del mes
        cTemp.set(Calendar.DAY_OF_MONTH, 1);
        String fechaIni = dateFormat.format(cTemp.getTime());
        // Obtener último día del mes
        cTemp.set(Calendar.DAY_OF_MONTH, ultimoDia);
        String fechaFin = dateFormat.format(cTemp.getTime());

        // Ingreso a la base de datos
        valores.put("PRE_monto", monto);
        valores.put("PRE_FechaIn", fechaIni);
        valores.put("PRE_FechaFn", fechaFin);
        valores.put("USU_ID", usuId);
        long resultado = db.insert("PRESUPUESTO", null, valores);
        return (int)resultado;
    }
    public void actualizarPresupuesto(double monto, String fecha){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put("PRE_Monto", monto);
        db.execSQL(
                "UPDATE PRESUPUESTO " +
                        "SET PRE_monto = PRE_monto + ? " +
                        "WHERE ? BETWEEN PRE_FechaIn AND PRE_FechaFn",
                new Object[]{monto, fecha});
        // Actualizar los presupuestos posteriores al actual
        // Obtener la fecha final del presupuesto afectado
        Cursor cursor = db.rawQuery(
                "SELECT PRE_FechaFn FROM PRESUPUESTO " +
                        "WHERE ? BETWEEN PRE_FechaIn AND PRE_FechaFn",
                new String[]{fecha}
        );
        if (cursor.moveToFirst()) {
            String fechaLimite = cursor.getString(0); // PRE_FechaFn

            // 3. Actualizar todos los presupuestos posteriores
            db.execSQL(
                    "UPDATE PRESUPUESTO " +
                            "SET PRE_monto = PRE_monto + ? " +
                            "WHERE PRE_FechaIn > ?",
                    new Object[]{monto, fechaLimite}
            );
        }
        cursor.close();
    }
    public double getPresupuestoMesAct(){
        SQLiteDatabase db = this.getWritableDatabase();
        double resp = 0;
        Calendar calendario = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String fechaAct = simpleDateFormat.format(calendario.getTime());

        Cursor cursor = db.rawQuery("SELECT PRE_monto FROM PRESUPUESTO " +
                "WHERE ? BETWEEN PRE_FechaIn AND PRE_FechaFn", new String[]{fechaAct});
        if (cursor.moveToFirst()){
            resp = cursor.getInt(0);
        }
        return resp;
    }

    //Ingresos

    public boolean insertarIngreso(double monto, String descripcion, String fecha, String clase) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues valores = new ContentValues();
        int preId = 0;
        String fechaini = null, fechafin = null;
        Cursor cursor1 = db.rawQuery("SELECT PRE_ID FROM PRESUPUESTO " +
                "WHERE (? >= PRE_FechaIn AND ? <= PRE_FechaFn)", new String[]{fecha, fecha});
        if (cursor1.moveToFirst()){
            preId = cursor1.getInt(0);
        }
        else{
            double montoTemp = 0;
            Cursor cursor2 = db.rawQuery("SELECT * FROM PRESUPUESTO " +
                    "WHERE PRE_ID = (SELECT MAX(PRE_ID) FROM PRESUPUESTO)", null);
            if (cursor2.moveToFirst()){
                montoTemp = cursor2.getDouble(1);
                preId = cursor2.getInt(0);
            }
            preId += 1;

            String[] partes = fecha.split("-");
            int year = Integer.parseInt(partes[0]);
            int month = Integer.parseInt(partes[1]) - 1;
            int day = Integer.parseInt(partes[2]);

            Calendar calendario = Calendar.getInstance();
            calendario.set(year, month, day);

            insertarPresupuesto(montoTemp, calendario, "1");
            cursor2.close();
        }
        cursor1.close();


        valores.put("ING_monto", monto);
        valores.put("ING_desc", descripcion);
        valores.put("ING_Fecha", fecha);
        valores.put("ING_clas", clase);
        valores.put("PRE_ID", preId);
        long resultado = db.insert("INGRESOS", null, valores);

        // Actualizar presupuesto
        actualizarPresupuesto(monto, fecha);

        return resultado != -1;
    }

    //Gastos
    public boolean insertarGasto(double monto, String descripcion, String fecha, String categoria) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues valores = new ContentValues();
        int preId = 0;
        String fechaini = null, fechafin = null;
        Cursor cursor1 = db.rawQuery("SELECT PRE_ID FROM PRESUPUESTO " +
                "WHERE ? BETWEEN PRE_FechaIn AND PRE_FechaFn", new String[]{fecha});
        if (cursor1.moveToFirst()){
            preId = cursor1.getInt(0);
        }
        else{
            double montoTemp = 0;
            Cursor cursor2 = db.rawQuery("SELECT PRE_ID FROM PRESUPUESTO " +
                    "WHERE PRE_ID = (SELECT MAX(PRE_ID) FROM PRESUPUESTO)", null);
            if (cursor2.moveToFirst()){
                montoTemp = cursor2.getDouble(1);
            }

            String[] partes = fecha.split("-");
            int year = Integer.parseInt(partes[0]);
            int month = Integer.parseInt(partes[1]) - 1;
            int day = Integer.parseInt(partes[2]);

            Calendar calendario = Calendar.getInstance();
            calendario.set(year, month, day);

            // Insertar nuevo presupuesto, dejando que SQLite genere el ID
            preId = insertarPresupuesto(montoTemp, calendario, "1");
            cursor2.close();
        }
        cursor1.close();

        valores.put("GAS_monto", monto);
        valores.put("GAS_desc", descripcion);
        valores.put("GAS_Fecha", fecha);
        valores.put("PRE_ID", preId);
        long resultado = db.insert("GASTOS", null, valores);

        // intersección con tabla CLASIF_GASTOS
        int clasId = 0;
        Cursor cursor = db.rawQuery("SELECT CLA_ID FROM CLASIFICACION " +
                "WHERE CLA_Nombre = ?", new String[]{categoria});
        if (cursor.moveToFirst()){
            clasId = cursor.getInt(0);
        }
        insertarClasificacionGasto((int) resultado, clasId);
        // Actualizar presupuesto
        actualizarPresupuesto(-monto, fecha);

        return resultado != -1;
    }

    //CLasificacion
    public boolean insertarClasificacion(String nombre, String descripcion) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues valores = new ContentValues();

        valores.put("CLA_nombre", nombre);
        valores.put("CLA_descr", descripcion);
        long resultado = db.insert("CLASIFICACION", null, valores);
        return resultado != -1;
    }

    //Tabla Intermedia
    public boolean insertarClasificacionGasto(int gasId, int claId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put("GAS_ID", gasId);
        valores.put("CLA_ID", claId);
        long resultado = db.insert("CLAS_GASTOS", null, valores);
        return resultado != -1;
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS CLAS_GASTOS");
        db.execSQL("DROP TABLE IF EXISTS GASTOS");
        db.execSQL("DROP TABLE IF EXISTS INGRESOS");
        db.execSQL("DROP TABLE IF EXISTS RETOS");
        db.execSQL("DROP TABLE IF EXISTS META");
        db.execSQL("DROP TABLE IF EXISTS PRESUPUESTO");
        db.execSQL("DROP TABLE IF EXISTS CLASIFICACION");
        db.execSQL("DROP TABLE IF EXISTS USUARIO");

        // Crea las tablas de nuevo
        onCreate(db);
    }

}
