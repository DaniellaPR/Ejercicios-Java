package com.kaputt.kapputtapp.ui.retos;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.kaputt.kapputtapp.R;
import com.kaputt.kapputtapp.ui.anadir.anadirGasto;

public class RetosFragment extends Fragment {

    public RetosFragment() {
        // Constructor vacío
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_retos, container, false);
        ImageButton btnAnadirGasto = view.findViewById(R.id.btnAgregarMeta);

        btnAnadirGasto.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), anadirGasto.class);
            startActivity(intent);
        });
        return view;
    }

    //
}
