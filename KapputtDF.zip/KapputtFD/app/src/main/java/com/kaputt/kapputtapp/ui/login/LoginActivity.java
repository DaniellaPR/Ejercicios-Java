package com.kaputt.kapputtapp.ui.login;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.kaputt.kapputtapp.MainActivity;
import com.kaputt.kapputtapp.R;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText balanceEditText;
    private Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Validar si ya entró antes
        SharedPreferences prefs = getSharedPreferences("KaputtPrefs", MODE_PRIVATE);
        boolean isFirstTime = prefs.getBoolean("isFirstTime", true);

        if (!isFirstTime) {
            // Ya inició antes, redirigir directamente
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_login);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        usernameEditText = findViewById(R.id.username);
        balanceEditText = findViewById(R.id.editTextNumber);
        loginButton = findViewById(R.id.login);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString().trim();
                String balance = balanceEditText.getText().toString().trim();

                if (username.isEmpty()) {
                    usernameEditText.setError("Por favor ingresa tu nombre");
                    return;
                }

                if (balance.isEmpty()) {
                    balanceEditText.setError("Por favor ingresa tu balance");
                    return;
                }

                Toast.makeText(LoginActivity.this, "Bienvenido, " + username + "!", Toast.LENGTH_SHORT).show();

                // Guardar flag de primera vez
                SharedPreferences.Editor editor = prefs.edit();
                editor.putBoolean("isFirstTime", false);
                editor.apply();

                startActivity(new Intent(LoginActivity.this, MainActivity.class));
                finish();
            }
        });
    }
}
